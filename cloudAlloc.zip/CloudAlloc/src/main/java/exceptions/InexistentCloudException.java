package exceptions;

/**
 *
 * @author O Grupo
 */
public class InexistentCloudException extends Exception {

  public InexistentCloudException() {
  }

  public InexistentCloudException(String message) {
    super(message);
  }

}
