package exceptions;

/**
 *
 * @author O Grupo
 */
public class UserDoesNotOwnCloudException extends Exception {

  public UserDoesNotOwnCloudException() {
  }

  public UserDoesNotOwnCloudException(String message) {
    super(message);
  }

}
